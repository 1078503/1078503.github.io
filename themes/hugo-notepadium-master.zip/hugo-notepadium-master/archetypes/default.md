+++
title = "{{ replace .Name `-` ` ` | title }}"
date = {{ .Date }}
lastmod = {{ .Date }}
tags = []
categories = []
imgs = []
cover = ""  # image show on top
readingTime = true  # show reading time after article date
toc = true
comments = false
justify = false  # text-align: justify;
single = false  # display as a single page, hide navigation on bottom, like as about page.
license = ""  # CC License
draft = true
+++

